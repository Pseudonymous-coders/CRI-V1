/* Code compiled by the SCO compiler apparently likes this to be defined.  */

int __fltused = 1;
