/* This function is available as a system call.  */
