/* XXX We will have to see whether it is possible to implement this
   function at all.  */
