#include <sysdeps/unix/sysv/sysv4/setsid.c>
