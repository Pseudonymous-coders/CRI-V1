/* SVR4 uses the POSIX dup2.  */
#include <sysdeps/posix/dup2.c>
