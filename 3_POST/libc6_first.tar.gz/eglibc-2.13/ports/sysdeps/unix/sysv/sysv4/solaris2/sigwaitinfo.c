/* We can reuse the Linux implementation.  */
#include <sysdeps/unix/sysv/linux/sigwaitinfo.c>
