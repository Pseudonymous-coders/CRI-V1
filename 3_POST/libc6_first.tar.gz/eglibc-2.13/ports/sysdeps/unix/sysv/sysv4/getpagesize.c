/* Solaris uses sysconf ala POSIX.1.  */
#include <sysdeps/posix/getpagesize.c>
