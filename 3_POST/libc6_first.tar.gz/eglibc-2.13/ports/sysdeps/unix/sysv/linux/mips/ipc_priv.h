#include <sysdeps/unix/sysv/linux/alpha/ipc_priv.h>
