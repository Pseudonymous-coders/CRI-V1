#include <sysdeps/unix/sysv/linux/i386/setresuid.c>
