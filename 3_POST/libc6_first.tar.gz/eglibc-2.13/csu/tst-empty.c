/* The most useful C program known to man.  */
int
main (void)
{
  return 0;
}
